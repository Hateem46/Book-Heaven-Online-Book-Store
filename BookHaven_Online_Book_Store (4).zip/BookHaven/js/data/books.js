/* BookHaven - Book data (catalogue)
   Developed by Mohammed Hateem */

const books = [
  { id: 1, title: "The Silent Garden",       author: "Mira Sen",     category: "Fiction",    price: 349, cover: "cover-1", tag: "A NOVEL" },
  { id: 2, title: "Small Steps, Big Change", author: "Aarav Mehta",  category: "Self-help",  price: 299, cover: "cover-2", tag: "GROW EVERY DAY" },
  { id: 3, title: "Code the Future",         author: "Rohan Iyer",   category: "Technology", price: 499, cover: "cover-3", tag: "TECHNOLOGY" },
  { id: 4, title: "The Money Map",           author: "Nisha Rao",    category: "Business",   price: 399, cover: "cover-4", tag: "SMART FINANCE" },
  { id: 5, title: "Letters to the Moon",     author: "Sara Khan",    category: "Fiction",    price: 279, cover: "cover-5", tag: "A STORY" },
  { id: 6, title: "Think Clearly",           author: "Dev Malhotra", category: "Self-help",  price: 325, cover: "cover-6", tag: "MIND & HABITS" },
  { id: 7, title: "Digital Horizons",        author: "Kabir Shah",   category: "Technology", price: 549, cover: "cover-7", tag: "INNOVATION" },
  { id: 8, title: "Build Your Venture",      author: "Anaya Desai",  category: "Business",   price: 429, cover: "cover-8", tag: "STARTUP GUIDE" }
];
