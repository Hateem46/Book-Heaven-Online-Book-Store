/* BookHaven - Small helper functions (price format, toast message)
   Developed by Mohammed Hateem */

// Format a number as Indian Rupees, e.g. 1299 -> "₹1,299"
const money = value => "₹" + value.toLocaleString("en-IN");

// Show a short message at the bottom of the screen
let toastTimer;
function showToast(message) {
  const toast = document.getElementById("toast");
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2100);
}
