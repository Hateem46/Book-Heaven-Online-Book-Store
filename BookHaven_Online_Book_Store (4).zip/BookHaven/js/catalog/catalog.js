/* BookHaven - Book catalogue (search, category filter, sort, cards)
   Developed by Mohammed Hateem */

const bookGrid = document.getElementById("bookGrid");

function getVisibleBooks() {
  const term     = document.getElementById("searchInput").value.trim().toLowerCase();
  const category = document.getElementById("categoryFilter").value;
  const sort     = document.getElementById("sortFilter").value;

  const shown = books.filter(book =>
    (category === "All" || book.category === category) &&
    (book.title.toLowerCase().includes(term) || book.author.toLowerCase().includes(term))
  );

  if (sort === "low")  shown.sort((a, b) => a.price - b.price);
  if (sort === "high") shown.sort((a, b) => b.price - a.price);
  if (sort === "name") shown.sort((a, b) => a.title.localeCompare(b.title));

  return shown;
}

function bookCardHTML(book) {
  return `
    <article class="book-card">
      <div class="cover-wrap">
        <div class="book-cover ${book.cover}">
          <span class="cover-tag">${book.tag}</span>
          <span class="cover-title">${book.title}</span>
          <span class="cover-author">${book.author.toUpperCase()}</span>
        </div>
      </div>
      <div class="book-category">${book.category}</div>
      <h3 class="book-title">${book.title}</h3>
      <div class="book-author">by ${book.author}</div>
      <div class="book-bottom">
        <span class="book-price">${money(book.price)}</span>
        <button class="add-button" data-add="${book.id}">+ Add to cart</button>
      </div>
    </article>`;
}

function renderBooks() {
  const shown = getVisibleBooks();
  document.getElementById("resultCount").textContent = `${shown.length} book${shown.length === 1 ? "" : "s"}`;
  document.getElementById("emptyState").classList.toggle("hidden", shown.length !== 0);
  bookGrid.innerHTML = shown.map(bookCardHTML).join("");
}

function initCatalog() {
  document.getElementById("searchInput").addEventListener("input", renderBooks);
  document.getElementById("categoryFilter").addEventListener("change", renderBooks);
  document.getElementById("sortFilter").addEventListener("change", renderBooks);

  // "Add to cart" buttons on the book cards
  bookGrid.addEventListener("click", event => {
    const button = event.target.closest("[data-add]");
    if (button) addToCart(Number(button.dataset.add));
  });

  renderBooks();
}
