/* BookHaven - Checkout popup and demo order
   Developed by Mohammed Hateem */

const checkoutModal = document.getElementById("checkoutModal");

function openCheckout() {
  if (!cart.length) return;
  closeCart();
  checkoutModal.classList.remove("hidden");
}

function closeCheckout() {
  checkoutModal.classList.add("hidden");
}

function placeOrder(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const customer = new FormData(form).get("customerName");
  const orderId = "BH" + Math.floor(100000 + Math.random() * 900000);

  clearCart();
  form.reset();
  closeCheckout();
  showToast(`Thank you ${customer}! Demo order ${orderId} placed.`);
}

function initCheckout() {
  document.getElementById("checkoutButton").addEventListener("click", openCheckout);
  document.getElementById("closeCheckout").addEventListener("click", closeCheckout);
  document.getElementById("checkoutForm").addEventListener("submit", placeOrder);
}
