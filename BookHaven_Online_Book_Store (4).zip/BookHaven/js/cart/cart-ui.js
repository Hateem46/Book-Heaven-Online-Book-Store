/* BookHaven - Cart drawer (what the user sees + its buttons)
   Developed by Mohammed Hateem */

const cartDrawer = document.getElementById("cartDrawer");
const overlay    = document.getElementById("overlay");
const cartItems  = document.getElementById("cartItems");
const cartEmpty  = document.getElementById("cartEmpty");
const cartFooter = document.getElementById("cartFooter");

function renderCart() {
  const total = getCartTotal();

  document.getElementById("cartCount").textContent = getCartCount();
  document.getElementById("cartSubtotal").textContent = money(total);
  document.getElementById("checkoutTotal").textContent = money(total);

  cartEmpty.classList.toggle("hidden", cart.length !== 0);
  cartFooter.classList.toggle("hidden", cart.length === 0);

  cartItems.innerHTML = cart.map(item => {
    const book = findBook(item.id);
    return `
      <div class="cart-row">
        <div class="mini-cover ${book.cover}">${book.title}</div>
        <div>
          <div class="cart-book-name">${book.title}</div>
          <div class="cart-book-meta">${money(book.price)} each</div>
          <div class="qty-controls">
            <button data-qty="${book.id}" data-delta="-1">−</button>
            <span>${item.qty}</span>
            <button data-qty="${book.id}" data-delta="1">+</button>
          </div>
          <button class="remove-item" data-remove="${book.id}">Remove</button>
        </div>
        <div class="cart-line-price">${money(book.price * item.qty)}</div>
      </div>`;
  }).join("");
}

function openCart() {
  cartDrawer.classList.add("open");
  cartDrawer.setAttribute("aria-hidden", "false");
  overlay.classList.remove("hidden");
}

function closeCart() {
  cartDrawer.classList.remove("open");
  cartDrawer.setAttribute("aria-hidden", "true");
  overlay.classList.add("hidden");
}

function initCartUI() {
  document.getElementById("openCart").addEventListener("click", openCart);
  document.getElementById("closeCart").addEventListener("click", closeCart);
  document.getElementById("continueShopping").addEventListener("click", closeCart);
  overlay.addEventListener("click", closeCart);

  // Quantity (+ / −) and Remove buttons inside the cart
  cartItems.addEventListener("click", event => {
    const qty = event.target.closest("[data-qty]");
    const remove = event.target.closest("[data-remove]");
    if (qty) changeQty(Number(qty.dataset.qty), Number(qty.dataset.delta));
    if (remove) removeFromCart(Number(remove.dataset.remove));
  });

  renderCart();
}
