/* BookHaven - Cart logic (data only, no HTML here)
   Developed by Mohammed Hateem */

const CART_KEY = "bookhaven-cart";

// Cart is an array of { id, qty } and is saved in the browser's LocalStorage
let cart = JSON.parse(localStorage.getItem(CART_KEY) || "[]");

function findBook(id) {
  return books.find(book => book.id === id);
}

function saveCart() {
  localStorage.setItem(CART_KEY, JSON.stringify(cart));
  renderCart(); // defined in cart-ui.js
}

function addToCart(id) {
  const item = cart.find(row => row.id === id);
  if (item) item.qty++;
  else cart.push({ id, qty: 1 });
  saveCart();
  showToast("Book added to your cart");
}

function changeQty(id, delta) {
  const item = cart.find(row => row.id === id);
  if (!item) return;
  item.qty += delta;
  if (item.qty <= 0) cart = cart.filter(row => row.id !== id);
  saveCart();
}

function removeFromCart(id) {
  cart = cart.filter(item => item.id !== id);
  saveCart();
}

function clearCart() {
  cart = [];
  saveCart();
}

function getCartCount() {
  return cart.reduce((sum, item) => sum + item.qty, 0);
}

function getCartTotal() {
  return cart.reduce((sum, item) => sum + findBook(item.id).price * item.qty, 0);
}
