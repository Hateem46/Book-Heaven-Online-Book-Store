/* BookHaven - Online Book Store
   Main file: starts every part of the website.
   Developed by Mohammed Hateem */

initCartUI();
initCatalog();
initCheckout();
