BOOKHAVEN - ONLINE BOOK STORE DEMO
==================================
Developed by: Mohammed Hateem

HOW TO RUN
1. Extract the ZIP file to a folder on your computer.
2. Open the folder in Visual Studio Code.
3. Open index.html.
4. Right-click inside index.html and choose "Open with Live Server" (if the Live Server extension is installed).
   OR double-click index.html to open it directly in Chrome/Edge.

FEATURES
- Responsive online bookstore interface
- Book catalogue with categories
- Search by book title or author
- Sort books by price or name
- Add books to cart
- Increase/decrease quantity and remove books
- Automatic subtotal calculation
- Cart saved in browser LocalStorage
- Demo checkout form and order confirmation

PROJECT STRUCTURE
BookHaven/
|-- index.html              Main page
|-- README.txt
|-- assets/
|   `-- favicon.svg         Browser tab icon
|-- css/
|   |-- base.css            Colours, reset, shared buttons
|   |-- header.css          Top bar, logo, cart button
|   |-- hero.css            Hero section
|   |-- benefits.css        Benefits strip
|   |-- catalog.css         Search, filters, book cards
|   |-- covers.css          Book cover designs
|   |-- about.css           About / quote band
|   |-- footer.css          Footer + developer credit
|   |-- cart.css            Cart drawer
|   |-- checkout.css        Checkout popup
|   |-- toast.css           Notification message
|   `-- responsive.css      Tablet and mobile layout
`-- js/
    |-- data/books.js       List of books
    |-- utils/helpers.js    Price format + toast message
    |-- cart/cart.js        Cart logic (add, remove, total)
    |-- cart/cart-ui.js     Cart drawer display + buttons
    |-- catalog/catalog.js  Search, filter, sort, book cards
    |-- checkout/checkout.js Checkout popup + demo order
    `-- main.js             Starts everything

IMPORTANT
This is a front-end academic demonstration project. It does not process real payments,
send emails, or store orders on a server. Checkout is a sample flow only.

TECHNOLOGIES
HTML5, CSS3, JavaScript, Browser LocalStorage
